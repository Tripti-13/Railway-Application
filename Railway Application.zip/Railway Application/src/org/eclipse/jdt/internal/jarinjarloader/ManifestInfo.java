

package org.eclipse.jdt.internal.jarinjarloader;

class ManifestInfo {
    String rsrcMainClass;
    String[] rsrcClassPath;

    private ManifestInfo() {
    }
}
